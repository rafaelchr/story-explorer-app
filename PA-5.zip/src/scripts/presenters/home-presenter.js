class HomePresenter {
  constructor(view, model) {
    this.view = view;
    this.model = model;
    this.stories = [];
    this.currentPage = 1;
    this.pageSize = 10;
    this.location = 0;
  }

  async init() {
    try {
      this.view.showLoading();
      this.currentPage = 1;
      const storiesData = await this.model.getAllStories(this.currentPage, this.pageSize, this.location);

      if (storiesData.error) {
        this.view.hideLoading();
        this.view.showError(storiesData.message);
        return;
      }

      this.stories = storiesData.listStory;

      this.view.displayStories(this.stories);
      this.view.initializeMap(this.stories);

      this.view.hideLoading();
    } catch (error) {
      this.view.hideLoading();
      this.view.showError('Failed to load stories. Please try again.');
      console.error('Error in HomePresenter:', error);
    }
  }

  async refreshStories() {
    await this.init();
  }

  onStoryClick(storyId) {
    const story = this.stories.find(s => s.id === storyId);
    if (story) {
      this.view.navigateToStory(storyId);
    }
  }

  getStories() {
    return this.stories;
  }

  async loadMoreStories() {
    try {
      this.currentPage += 1;
      const storiesData = await this.model.getAllStories(this.currentPage, this.pageSize, this.location);

      if (!storiesData.error && storiesData.listStory.length > 0) {
        this.stories = [...this.stories, ...storiesData.listStory];
        this.view.appendStories(storiesData.listStory);
        return true;
      } else {
        this.currentPage -= 1;
        return false;
      }
    } catch (error) {
      this.view.showError('Failed to load more stories.');
      return false;
    }
  }
}

export default HomePresenter;
