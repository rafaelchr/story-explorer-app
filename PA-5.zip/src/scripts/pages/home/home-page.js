import HomePresenter from "../../presenters/home-presenter";
import StoryModel from "../../data/story-model";

export default class HomePage {
  constructor() {
    this.presenter = null;
    this.map = null;
  }

  async render() {
    return `
      <section class="home-main" id="main-section" tabindex="-1">
        <section class="hero">
          <h1>Story Explorer</h1>
          <p>Discover amazing stories from around the world</p>
        </section>

        <section class="stories-section">
          <h2>Latest Stories</h2>

          <div id="loading" class="loading hidden" aria-live="polite">
            <div class="spinner"></div>
            <p>Loading stories...</p>
          </div>

          <div id="error-message" class="error-message hidden" role="alert" aria-live="assertive"></div>

          <div id="stories-container" class="stories-grid"></div>
        </section>

        <section class="map-section">
          <h2>Story Locations</h2>
          <div id="map" class="map-container" role="img" aria-label="Interactive map showing story locations"></div>
        </section>
      </section>
    `;
  }

  async afterRender() {
    const model = new StoryModel();
    this.presenter = new HomePresenter(this, model);
    await this.presenter.init();
  }

  showLoading() {
    document.getElementById("loading")?.classList.remove("hidden");
  }

  hideLoading() {
    document.getElementById("loading")?.classList.add("hidden");
  }

  showError(message) {
    const errorElement = document.getElementById("error-message");
    if (errorElement) {
      errorElement.textContent = message;
      errorElement.classList.remove("hidden");
    }
  }

  displayStories(stories) {
    const container = document.getElementById("stories-container");
    if (!container) return;

    container.innerHTML = this.generateStoriesHTML(stories);
    this.attachStoryCardEvents(container);
  }

  appendStories(newStories) {
    const container = document.getElementById("stories-container");
    if (!container) return;

    const newHTML = this.generateStoriesHTML(newStories);
    container.insertAdjacentHTML("beforeend", newHTML);

    const newCards = container.querySelectorAll(
      ".story-card:not([data-events-attached])"
    );
    this.attachStoryCardEvents(container, newCards);
  }

  generateStoriesHTML(stories) {
    return stories
      .map(
        (story) => `
    <article class="story-card" data-story-id="${story.id}">
      <img src="${story.photoUrl}" alt="Story photo: ${
          story.description
        }" class="story-image" loading="lazy">
      <div class="story-content">
        <h3 class="story-title">${story.name}</h3>
        <p class="story-description">${story.description}</p>
        <time class="story-date" datetime="${story.createdAt}">
          ${new Date(story.createdAt).toLocaleDateString()}
        </time>
        ${
          story.lat && story.lon
            ? `<p class="story-location">📍 <br>Lat: ${story.lat}<br>Lon: ${story.lon}</p>`
            : ""
        }
        <button class="detail-button" data-story-id="${
          story.id
        }" aria-label="View details for story by ${story.name}">Detail</button>
      </div>
    </article>
  `
      )
      .join("");
  }

  attachStoryCardEvents(container, cards = null) {
    const storyCards = cards || container.querySelectorAll(".story-card");

    storyCards.forEach((card) => {
      if (card.dataset.eventsAttached) return;

      const storyId = card.dataset.storyId;

      // Event untuk seluruh card
      const cardHandler = () => {
        this.presenter.onStoryClick(storyId);
      };

      card.addEventListener("click", cardHandler);
      card.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          cardHandler();
        }
      });

      // Event khusus tombol "Detail"
      const detailButton = card.querySelector(".detail-button");
      if (detailButton) {
        detailButton.addEventListener("click", (e) => {
          e.stopPropagation(); // Hindari trigger event card
          this.presenter.onStoryClick(storyId);
        });
      }

      card.dataset.eventsAttached = "true";
    });
  }

  navigateToStory(storyId) {
    window.location.hash = `/detail/${storyId}`;
  }

  initializeMap(stories) {
    if (this.map) {
      this.map.remove();
    }

    this.map = L.map("map").setView([-6.2088, 106.8456], 5);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
    }).addTo(this.map);

    stories.forEach((story) => {
      if (story.lat && story.lon) {
        const marker = L.marker([story.lat, story.lon]).addTo(this.map);
        marker.bindPopup(`
          <div class="map-popup">
            <h4>${story.name}</h4>
            <p>${story.description}</p>
            <img src="${story.photoUrl}" alt="Story photo" style="width: 150px; height: 100px; object-fit: cover; border-radius: 4px;">
          </div>
        `);
      }
    });
  }
}
