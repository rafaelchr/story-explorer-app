class StoryModel {
  constructor() {
    this.baseUrl = "https://story-api.dicoding.dev/v1";
  }

  async getAllStories(page = 1, size = 10, location = 0) {
    try {
      const token = localStorage.getItem("authToken"); // pastikan token disimpan di localStorage
      const response = await fetch(
        `${this.baseUrl}/stories?page=${page}&size=${size}&location=${location}`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Error fetching stories:", error);
      return {
        error: true,
        message: "Failed to fetch stories.",
        listStory: [],
      };
    }
  }

  async addStory({ description, photo, lat, lon }) {
    const token = localStorage.getItem("authToken");

    const formData = new FormData();
    formData.append("description", description);
    formData.append("photo", photo);
    if (lat !== undefined && lat !== null) formData.append("lat", lat);
    if (lon !== undefined && lon !== null) formData.append("lon", lon);

    try {
      const response = await fetch(`${this.baseUrl}/stories`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error("Error adding story:", error);
      return { error: true, message: "Failed to add story." };
    }
  }

  async getStoryById(id) {
    const token = localStorage.getItem("authToken");
    const response = await fetch(`${this.baseUrl}/stories/${id}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const result = await response.json();

    if (!response.ok || result.error) {
      throw new Error(result.message || "Failed to fetch story");
    }

    return result;
  }
}

export default StoryModel;
